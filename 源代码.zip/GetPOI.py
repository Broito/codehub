import requests
from tqdm import tqdm

ak = "AYYevDoTjfMMU18wHgBcde0LcBVVlspr"
poilist = {"综合医院": "hospital",
           "药店": "drugstore",
           "公园$休闲广场": "park&square",
           "公交车站": "busstop",
           "地铁站": "metrostation",
           "购物": "shop"}


def GetPOI(data):
    for i in tqdm(range(len(data))):
        line = data[i]
        lon = line["BLon"]
        lat = line["BLat"]
        for k in range(len(poilist)):
            p = poilist.keys()[k]
            url = "http://api.map.baidu.com/place/v2/search?query={}&location={},{}&radius=1000&output=json&ak={}".format(
                p, lat, lon, ak)
            re = eval(requests.get(url).text)["results"]
            line[poilist[p]] = len(re)
    return data
