import geopandas as gpd
import matplotlib.pyplot as plt
import shapely, fiona
import seaborn as sns
from fiona.crs import from_epsg, from_string


class Map():
    def __init__(self, _container):
        self.map = gpd.read_file('data/shanghai/Shanghai_WGS84.shp', encoding="utf8").plot()
        self.container = _container
        self.eventlist = dict()
        self.layerlist = []

    def AddEvent(self, _layer, _func):
        self.eventlist[_layer] = _func

    def AddLayer(self, _layer):
        self.layerlist.append(_layer)

    def load(self):
        for l in self.layerlist:
            print(l)

    def maptoContainer(self):
        pass

    def containertoMap(self, location):
        width = self.container.F.axes.axis()[1] - self.container.F.axes.axis()[0]
        height = self.container.F.axes.axis()[3] - self.container.F.axes.axis()[2]
        xscale = width / self.container.F.geometry().width()
        yscale = height / self.container.F.geometry().height()
        mx = self.container.F.axes.axis()[0] + xscale * location[0]
        my = self.container.F.axes.axis()[3] - yscale * location[1]
        return [mx, my]


    def ActiveEvent(self, _location):
        location = self.containertoMap(_location)
        for l in self.eventlist:
            if l.contain(location):
                pass



class Layer():
    def __init__(self, _map, _icon):
        self.map = _map
        self.icon = _icon
        self.display = True
        self.cluster = True
        self.dataset = None

    def setJson(self, _data):
        self.dataset = _data

    def setShp(self, _shpname):
        self.dataset = gpd.read_file(_shpname)

    def hide(self):
        self.display = True

    def show(self):
        self.display = False

    def draw(self):
        for f in self.dataset:
            f.draw()
            self.icon.draw(f.location)

    def contain(self, _location):
        pass

    def cluster(self):
        pass




class Icon():
    def __init__(self, _imagename, _anchor, _offset):
        self.map = gpd.read_file(_imagename)
        self.anchor = _anchor
        self.offset = _offset

    def draw(self, _location):
        pass


