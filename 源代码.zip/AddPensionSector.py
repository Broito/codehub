import requests
from bs4 import BeautifulSoup
from tqdm import tqdm

# 初始化URL和key标签
url = "http://www.shweilao.cn/index/facilities/details.html?id={0}&agencyType={1}"
key = ['养老机构', '护理站\院', '长者照护之家', '老年日间照护机构', '助餐服务点', '社区养老', '综合为老服务中心']
output = {'养老机构': [], '护理站\院': [], '长者照护之家': [], '老年日间照护机构': [], '助餐服务点': [], '社区养老': [], '综合为老服务中心': []}
T = {1: '养老机构', 7: '护理站\院', 2: '长者照护之家', 3: '老年日间照护机构', 4: '助餐服务点', 5: '社区养老', 6: '综合为老服务中心'}


def AddPS(data):
    for k in range(1, 8):
        atype = T[k]
        li = list(range(1, 10000))

        # 删除已有数据
        for p in data[atype]:
            li.remove(p["id"])

        # 遍历所有未读取id
        print("正在读爬取{}数据".format(atype))
        for i in tqdm(li):
            url0 = url.format(i, k)
            re = requests.get(url0).text  # 爬虫读取正文内容

            '''
            lxml解析html较快，但是部分html读取错误
            html5lib读取较慢，若使用异常，请改写BeautifulSoup解析器
            '''
            soup = BeautifulSoup(re, 'lxml')

            # 判断html是否为空
            if not soup.head.find_all("script"):
                continue
            if not soup.body.div.find_all(class_="show"):
                continue

            info = dict()
            info["name"] = str(soup.body.div.find_all(class_="fl fw_blod marginR20P")[0].string)
            info["id"] = i
            info["picture"] = soup.body.div.find_all(class_="show")[0].img["src"]
            if k == 7 or k == 6 or k == 4:
                infos = soup.body.div.find_all(class_="fr fs18 flex-wrap paddingR40P lh40P ie9_hidden")[0].find_all(
                    "div")
            elif k == 2 or k == 3 or k == 5:
                infos = soup.body.div.find_all(class_="fr fs16 flex-wrap paddingR40P lh40P ie9_hidden")[0].find_all(
                    "div")
            else:
                infos = soup.body.div.find_all(class_="fr fs18 flex-wrap paddingR40P lh40P clearfix")[0].find_all("div")
            if k == 1:
                tags = ["level", "service", "settime", "area", "telephone", "address", "facility"]
            elif k == 2:
                tags = ["settime", "telephone", "address", "facility"]
            elif k == 3 or k == 4 or k == 5:
                tags = ["settime", "telephone", "address"]
            elif k == 6:
                tags = ["settime", "area", "telephone", "address"]
            else:
                tags = ["address"]
            for index in range(len(tags)):
                try:
                    info_content = infos[0].find_all("li")[index].find_all("span")[1]
                except:
                    info[tags[index]] = ""
                else:
                    for string in info_content.strings:
                        info[tags[index]] = str(string).replace("\r\n", " ").replace("\t", "").replace(" ", "")
                try:
                    infos[0].find_all("li")[index + 1]
                except:
                    break
            if k == 1:
                tags = ["bed_all", "bed_empty", "cost", "availiable"]
            elif k == 2:
                tags = ["bed_all", "cost", "availiable"]
            elif k == 3:
                tags = ["cost", "bed_all"]
            elif k == 4:
                tags = ["service_type", "service_time"]
            elif k == 5:
                tags = ["service_content", "availiable"]
            elif k == 6:
                tags = ["service_content"]
            else:
                tags = ["certificate", "availiable", "agencytype"]
            for index in range(len(tags)):
                if (k == 1 or k == 2 or k == 5) and tags[index] == "availiable":
                    try:
                        info["availiable"] = str(infos[1].find_all("li")[index].find_all("span")[1].font.string)
                    except:
                        info["availiable"] = "否"
                elif k == 5 or k == 4:
                    try:
                        info_content = infos[2].find_all("li")[index].find_all("span")[1]
                    except:
                        info[tags[index]] = ""
                    else:
                        for string in info_content.strings:
                            info[tags[index]] = str(string).replace("\r\n", " ").replace("\t", "").replace(" ", "")
                elif k == 6:
                    info[tags[index]] = ""
                    for string in infos[1].find_all("li")[1].strings:
                        info[tags[index]] += str(string).strip()
                else:
                    for string in infos[1].find_all("li")[index].find_all("span")[1].strings:
                        info[tags[index]] = str(string).replace("\r\n", " ").replace("\t", "").replace(" ", "")
            output[atype].append(info)

    return output
