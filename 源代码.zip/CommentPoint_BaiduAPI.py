import json
import requests
import time
from DataBase import CommentDB
import pandas as pd

api_key = 'T0EkyNsyamer2tHyZ1umjaiw'
secret_key = 'HNA524hywuY8oYbtg56Y7RvuAPsF8TiV'

token_url = 'https://aip.baidubce.com/oauth/2.0/token'

host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={}&client_secret={}'.format(
    api_key, secret_key)
response = requests.get(host)
access_token = response.json()['access_token']

request_url = 'https://aip.baidubce.com/rpc/2.0/nlp/v2/comment_tag?charset=UTF-8&access_token={}'.format(access_token)

headers = {'content-type': "application/json"}


def get_comment_tag(_comment):
    _body = {'text': _comment, 'type': 6}
    print(_body)
    _re = requests.post(request_url, data=json.dumps(_body), headers=headers)
    print(_re)
    _text = eval(_re.content)['items']
    return _text


if __name__ == '__main__':

    comment = pd.read_csv('养老机构评论人工标注_lyq.csv', encoding='utf8')
    namelist = comment.index
    print(namelist)
    for i in range(834, len(comment)):
        name = comment.iloc[i, 0]
        text = comment.iloc[i, 1]
        print(name)
        print(text)
        req = get_comment_tag(text)
        print(req)
        CommentDB.insert(name, text, req)
        time.sleep(1)
        print(i)
