import requests
from tqdm import tqdm
from CoordTransform import gcj02_to_wgs84

# 初始化URL和AK码
URL = "http://api.map.baidu.com/geocoding/v3/?address={0}&output=json&ak={1}&ret_coordtype={2}"
CoordType = ["gcj02ll", "bd09mc", "bd09ll"]
ak = "AYYevDoTjfMMU18wHgBcde0LcBVVlspr"


# 初次爬取代码的错误部分
# info[309]["address"] = "青浦区华科路777号"
# info[636]["address"] = "奉贤区庄行镇新叶村村委会新叶村北环路村1366弄29号"
# info[576]["address"] = "松江区三新北路1800弄18号"
# info[1123]["address"] = "静安区临汾路街道临汾路三八零弄居委会阳曲路391弄16号"
# info[1453]["settime"] = info[1453]["telephone"]
# info[1453]["telephone"] = info[1453]["address"]
# info[1453]["address"] = "普陀区长寿路街道长四（居村委）宜昌路555号四楼、五楼"
# info[557]["address"] = "闵行区瓶北路467号"
# info[1548]["address"] = "静安区临汾路街道临汾路三八零弄居委会阳曲路391号16号"
# info[522]["address"] = "宝山区淞青路74-88号"
# info[1569]["address"] = "浦东新区老港镇宏港苑居委会宏港苑村建中路335号"
# info[319]["address"] = "青浦区金泽镇商榻北路310号"
# info[320]["address"] = "青浦区重固镇芦花浜路29号"
# info[472]["address"] = "杨浦区周家牌路217号"
# info[483]["address"] = "青浦区赵巷镇赵华路470号"
# info[507]["address"] = "青浦区香花桥街道北青公路普光路209号"
# info[1845]["address"] = "奉贤区金汇镇光辉村村委会光辉村村汇泰路16号"
# info[2039]["address"] = "金山区漕泾镇中一西路112号"
# info[2163]["settime"] = info[2163]["telephone"]
# info[2163]["telephone"] = info[2163]["address"]
# info[2163]["address"] = "闵行区华漕镇纪王村村委会（居村委）上海市闵行区华漕镇纪王村村委会纪翟路2780号"
# info[2176]["address"] = "闵行区曙建路78弄21号"
# info[2294]["address"] = "黄浦区五里桥街道瞿中居委会瞿溪路1111弄26号"
# info[2364]["address"] = "静安区临汾路街道岭南路一百弄居委会岭南路100弄4号"
# info[2366]["address"] = "静安区临汾路街道岭南路一百弄居委会岭南路100弄4号3楼"
# info[2460]["address"] = "奉贤区金汇镇光辉村村委会光辉村村汇泰路16号"
# info[2469]["address"] = "奉贤区庄行镇东风村村委会东风村腾庄路199弄188号"
# info[2470]["address"] = "奉贤区庄行镇丽水湾社区居委会丽水湾村三城路40号"
# info[1997]["address"] = "虹口区天宝路881号"
# info[1998]["address"] = "虹口区三门路726号"
# info[1999]["address"] = "虹口区提篮桥街道临潼路191号"
# info[2121]["address"] = "宝山区高逸路133号"
# info[2155]["address"] = "杨浦区平凉街道上海市济宁路488号"
# info[2164]["address"] = "黄浦区广东路525号"
# info[2338]["address"] = "闵行区梅陇镇许泾村2组61号、62号、63号"

def AddCoord(data):
    for k in list(data.keys()):
        print("正在为{}添加地理坐标".format(k))
        for line in tqdm(data[k]):
            if "bes_all" in list(line.keys()):
                line["bed_all"] = line["bes_all"]
                del line["bes_all"]
            url = URL.format(line["address"], ak, CoordType[0])
            re = eval(requests.get(url).text)
            line["GLon"] = re["result"]["location"]["lng"]
            line["GLat"] = re["result"]["location"]["lat"]
            url = URL.format(line["address"], ak, CoordType[1])
            re = eval(requests.get(url).text)
            line["MLon"] = re["result"]["location"]["lng"]
            line["MLat"] = re["result"]["location"]["lat"]
            url = URL.format(line["address"], ak, CoordType[2])
            re = eval(requests.get(url).text)
            line["BLon"] = re["result"]["location"]["lng"]
            line["BLat"] = re["result"]["location"]["lat"]
            [line["WLon"], line["WLat"]] = gcj02_to_wgs84(line["GLon"], line["GLat"])
    return data
