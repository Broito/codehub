import pandas as pd
import json


def AddGL(data1, path, col):
    data0 = pd.read_csv(path, encoding="utf8")

    for k in list(data1.keys()):
        for i in range(len(data1[k])):
            line = data1[k][i]
            line["greenland"] = float(data0.loc[i, col]) / 10000

    return data1


if __name__ == "__main__":
    DataPath = input("请输入New数据文件夹名")
    GLPath = input("请输入GreenLand数据地址：")
    GLColumn = input("请输入GreenLand行名：")
    with open(DataPath + "New.json", "r") as f:
        data = json.load(f)
    data = AddGL(data, GLPath, GLColumn)
    with open("data/" + DataPath + ".json", "w") as f:
        json.dump(data, f)
    with open("data/PensionSector.json", "w") as f:
        d = json.load(f)
        for k in list(data.keys()):
            d[k].append(data[k])
        json.dump(d, f)
