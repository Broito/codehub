from datetime import datetime
import json
from AddPensionSector import AddPS
from AddCoord import AddCoord
from GetPOI import GetPOI
from ClearData import ClearData
from JsontoCSV import JTC
import os


def mkdir(path):
    # 判断路径是否存在
    isExists = os.path.exists(path)

    # 判断结果
    if isExists:
        # 如果目录存在则不创建，并提示目录已存在
        print(path + ' 目录已存在')
        return False
    else:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path)

        print(path + ' 创建成功')
        return True


if __name__ == "__main__":
    pathname = datetime.now().strftime('%Y%m%d%H%M%S')
    filename = "data/" + pathname + "/New.json"
    mkdir(pathname)
    with open("data/PensionSector.json") as f:
        data = json.load(f)
    data = AddPS(data)
    data = AddCoord(data)
    data = GetPOI(data)
    data = ClearData(data)
    with open(filename, "w") as f:
        json.dump(data, f)
        print("爬取完成，路径名为{}".format(pathname))
    JTC(pathname, data)
