from tqdm import tqdm

def ClearData(data):
    for k in list(data.keys()):
        print("正在清理{}数据".format(k))
        for line in tqdm(data[k]):
            line["region"] = line["address"].split("区")[0] + "区"
            for key in list(line.keys()):
                try:
                    line["level"]
                except:
                    line["level"] = 0
                try:
                    line["service"]
                except:
                    line["service"] = 0
                if key == "level":
                    if line[key] == "(一级)":
                        line[key] = 1
                    elif line[key] == "(二级)":
                        line[key] = 2
                    elif line[key] == "(三级)":
                        line[key] = 3
                    else:
                        line[key] = 0
                elif key == "service":
                    if line[key] == "(较差)":
                        line[key] = 1
                    elif line[key] == "(一般)":
                        line[key] = 2
                    elif line[key] == "(良好)":
                        line[key] = 3
                    elif line[key] == "(优秀)":
                        line[key] = 3
                    else:
                        line[key] = 0
                else:
                    line[key] = line[key]
                try:
                    line["cost"]
                except:
                    line["avacost"] = 0
                else:
                    if line["cost"] == "0元/月" or line["cost"] == "":
                        line["avacost"] = 0
                    else:
                        if "-" in line["cost"]:
                            cost = line["cost"][:-3].split("-")
                            line["avacost"] = (int(cost[0]) + int(cost[1])) / 2
                        else:
                            line["avacost"] = int(line["cost"][:-3])
                try:
                    line["bed_all"]
                except:
                    bed_all = 0
                else:
                    if line["bed_all"] == "0":
                        line["bed_all"] = "0张"
                        bed_all = 0
                    elif line["bed_all"] == "(可致电咨询)":
                        bed_all = 0
                    else:
                        bed_all = int(line["bed_all"][:-1])
                try:
                    line["bed_empty"]
                except:
                    line["beduse"] = bed_all
                else:
                    if line["bed_empty"] == "0":
                        line["bed_empty"] = "0张"
                        bed_empty = 0
                    else:
                        bed_empty = int(line["bed_empty"][:-1])
                if bed_all == 0:
                    line["beduse"] = 0
                else:
                    line["beduse"] = 1 - bed_empty / bed_all
    return data
