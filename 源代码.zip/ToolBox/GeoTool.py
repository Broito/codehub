import math


def distance(lat1, lng1, lat2, lng2):
    radLat1 = float(lat1) * math.pi / 180
    radLat2 = float(lat2) * math.pi / 180
    a = radLat1 - radLat2
    b = float(lng1) * math.pi / 180 - float(lng2) * math.pi / 180
    s = 2 * math.asin(math.sqrt(math.pow(math.sin(a / 2), 2) +
                                math.cos(radLat1) * math.cos(radLat2) * math.pow(math.sin(b / 2), 2)))
    s = s * 6378.137  # EARTH_RADIUS
    s = round(s * 10000) / 10000
    return s
