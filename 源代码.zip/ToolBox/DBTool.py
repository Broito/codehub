def to_json(all_vendors):
    v = [ven.to_dict() for ven in all_vendors]
    return v


simple_tag = {'养老机构': ['bed_empty', 'telephone'],
              '护理站/院': ['address'],
              '老年日间照护机构': ['bed_all'],
              '长者照护之家': ['bed_all'],
              '助餐服务点': ['service_type', 'service_time'],
              '社区养老': ['service_content'],
              '综合为老服务中心': ['service_content']}

detail_tag = ['WLon', 'WLat', 'region',
              'cost', 'bed_used', 'level',
              'service', 'greenland', 'hospital',
              'drugstore', 'park_square', 'bus_stop',
              'metro_station', 'shop']


def simple(atype, data):
    data = to_json(data)

    output1 = []
    for j in data:
        output2 = {'id': j['id'],
                   'name': j['name'],
                   'address': j['address'],
                   'GLon': j['GLon'],
                   'GLat': j['GLat']}
        for k in simple_tag[atype]:
            output2[k] = j[k]
        output1.append(output2)
    return output1


def detailed(data):
    data = to_json(data)
    for j in data:
        for k in detail_tag:
            del j[k]
    return data
