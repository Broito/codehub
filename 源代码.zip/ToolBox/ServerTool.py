import json


def jsonp(data):
    callback = 'jsonpCallback'
    jsp = callback + '(' + json.dumps(data, ensure_ascii=False) + ')'
    return jsp  # 返回的是代码字样
