import os

os.system('python Server/UserServer.py')
os.system('python Server/CommentServer.py')
os.system('python Server/DataServer.py')
