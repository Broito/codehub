import json
import pandas as pd


def JTC(path, data):
    info = ["name", "WLon", "WLat"]

    table = pd.DataFrame(columns=info)
    l = {}

    for i in info:
        l[i] = []
    for k in data.keys():
        for line in data[k]:
            for i in info:
                l[i].append(line[i])
    for i in info:
        table[i] = l[i]

    table.to_csv("data/" + path + "/New_utf8.csv", encoding="utf8", index=False)
    table.to_csv("data/" + path + "/New_gbk.csv", encoding="gbk", index=False)
