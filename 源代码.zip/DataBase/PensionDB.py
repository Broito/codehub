from sqlalchemy import Column, Float, Integer, Text, create_engine
from sqlalchemy.dialects.mysql import TINYTEXT
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import json

con_engine = create_engine('mysql+pymysql://root:AEight19731224@localhost:3306/PensionWeb')
Base = declarative_base()
metadata = Base.metadata
DBSession = sessionmaker(bind=con_engine)
session = DBSession()


# 养老机构 NursingHome
class NH(Base):
    __tablename__ = 'NursingHome'

    id = Column(Integer, primary_key=True)
    name = Column(TINYTEXT)
    picture = Column(TINYTEXT)
    set_time = Column(TINYTEXT)
    area = Column(TINYTEXT)
    telephone = Column(TINYTEXT)
    address = Column(TINYTEXT)
    bed_all = Column(TINYTEXT)
    bed_empty = Column(TINYTEXT)
    price = Column(TINYTEXT)
    available = Column(TINYTEXT)
    GLon = Column(Float)
    GLat = Column(Float)
    WLon = Column(Float)
    WLat = Column(Float)
    region = Column(TINYTEXT)
    facility = Column(TINYTEXT)

    cost = Column(Float)
    bed_used = Column(Float)
    level = Column(Integer)
    service = Column(Integer)
    greenland = Column(Float)
    hospital = Column(Integer)
    drugstore = Column(Integer)
    park_square = Column(Integer)
    bus_stop = Column(Integer)
    metro_station = Column(Integer)
    shop = Column(Integer)

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


# 护理站/院 NursingStation
class NS(Base):
    __tablename__ = 'NursingStation'

    id = Column(Integer, primary_key=True)
    name = Column(TINYTEXT)
    picture = Column(TINYTEXT)
    address = Column(TINYTEXT)
    available = Column(TINYTEXT)
    GLon = Column(Float)
    GLat = Column(Float)
    WLon = Column(Float)
    WLat = Column(Float)
    region = Column(TINYTEXT)
    certificate = Column(TINYTEXT)

    cost = Column(Float)
    bed_used = Column(Float)
    level = Column(Integer)
    service = Column(Integer)
    greenland = Column(Float)
    hospital = Column(Integer)
    drugstore = Column(Integer)
    park_square = Column(Integer)
    bus_stop = Column(Integer)
    metro_station = Column(Integer)
    shop = Column(Integer)

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


# 老年日间照护机构 ElderlyDaycare
class ED(Base):
    __tablename__ = 'ElderlyDaycare'

    id = Column(Integer, primary_key=True)
    name = Column(TINYTEXT)
    picture = Column(TINYTEXT)
    set_time = Column(TINYTEXT)
    telephone = Column(TINYTEXT)
    address = Column(TINYTEXT)
    bed_all = Column(TINYTEXT)
    GLon = Column(Float)
    GLat = Column(Float)
    WLon = Column(Float)
    WLat = Column(Float)
    region = Column(TINYTEXT)

    cost = Column(Float)
    bed_used = Column(Float)
    level = Column(Integer)
    service = Column(Integer)
    greenland = Column(Float)
    hospital = Column(Integer)
    drugstore = Column(Integer)
    park_square = Column(Integer)
    bus_stop = Column(Integer)
    metro_station = Column(Integer)
    shop = Column(Integer)

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


# 长者照护之家 ElderNursing
class EN(Base):
    __tablename__ = 'ElderNursing'

    id = Column(Integer, primary_key=True)
    name = Column(TINYTEXT)
    picture = Column(TINYTEXT)
    set_time = Column(TINYTEXT)
    telephone = Column(TINYTEXT)
    address = Column(TINYTEXT)
    bed_all = Column(TINYTEXT)
    price = Column(TINYTEXT)
    available = Column(TINYTEXT)
    GLon = Column(Float)
    GLat = Column(Float)
    WLon = Column(Float)
    WLat = Column(Float)
    region = Column(TINYTEXT)
    facility = Column(TINYTEXT)

    cost = Column(Float)
    bed_used = Column(Float)
    level = Column(Integer)
    service = Column(Integer)
    greenland = Column(Float)
    hospital = Column(Integer)
    drugstore = Column(Integer)
    park_square = Column(Integer)
    bus_stop = Column(Integer)
    metro_station = Column(Integer)
    shop = Column(Integer)

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


# 助餐服务点 FoodService
class FS(Base):
    __tablename__ = 'FoodService'

    id = Column(Integer, primary_key=True)
    name = Column(TINYTEXT)
    picture = Column(TINYTEXT)
    set_time = Column(TINYTEXT)
    telephone = Column(TINYTEXT)
    address = Column(TINYTEXT)
    GLon = Column(Float)
    GLat = Column(Float)
    WLon = Column(Float)
    WLat = Column(Float)
    region = Column(TINYTEXT)
    service_type = Column(TINYTEXT)
    service_time = Column(TINYTEXT)

    cost = Column(Float)
    bed_used = Column(Float)
    level = Column(Integer)
    service = Column(Integer)
    greenland = Column(Float)
    hospital = Column(Integer)
    drugstore = Column(Integer)
    park_square = Column(Integer)
    bus_stop = Column(Integer)
    metro_station = Column(Integer)
    shop = Column(Integer)

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


# 社区养老 ElderlyCommunity
class EC(Base):
    __tablename__ = 'ElderlyCommunity'

    id = Column(Integer, primary_key=True)
    name = Column(TINYTEXT)
    picture = Column(TINYTEXT)
    set_time = Column(TINYTEXT)
    telephone = Column(TINYTEXT)
    address = Column(TINYTEXT)
    available = Column(TINYTEXT)
    GLon = Column(Float)
    GLat = Column(Float)
    WLon = Column(Float)
    WLat = Column(Float)
    region = Column(TINYTEXT)
    service_content = Column(Text)

    cost = Column(Float)
    bed_used = Column(Float)
    level = Column(Integer)
    service = Column(Integer)
    greenland = Column(Float)
    hospital = Column(Integer)
    drugstore = Column(Integer)
    park_square = Column(Integer)
    bus_stop = Column(Integer)
    metro_station = Column(Integer)
    shop = Column(Integer)

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


# 综合为老服务中心 ComprehensiveService
class CS(Base):
    __tablename__ = 'ComprehensiveService'

    id = Column(Integer, primary_key=True)
    name = Column(TINYTEXT)
    picture = Column(TINYTEXT)
    set_time = Column(TINYTEXT)
    area = Column(TINYTEXT)
    telephone = Column(TINYTEXT)
    address = Column(TINYTEXT)
    GLon = Column(Float)
    GLat = Column(Float)
    WLon = Column(Float)
    WLat = Column(Float)
    region = Column(TINYTEXT)
    service_content = Column(Text)

    cost = Column(Float)
    bed_used = Column(Float)
    level = Column(Integer)
    service = Column(Integer)
    greenland = Column(Float)
    hospital = Column(Integer)
    drugstore = Column(Integer)
    park_square = Column(Integer)
    bus_stop = Column(Integer)
    metro_station = Column(Integer)
    shop = Column(Integer)

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


def create(_agency, _data):
    if _agency == '养老机构':
        if _data.get('facility'):
            _data["facility"] = _data["facility"].split("\\")[0]
        return NH(id=_data.get('id'),
                  name=_data.get('name'),
                  picture=_data.get('picture'),
                  set_time=_data.get('settime', '0001-01-01'),
                  area=_data.get('area', '0'),
                  telephone=_data.get('telephone', ''),
                  address=_data.get('address'),
                  bed_all=_data.get('bed_all', '0'),
                  bed_empty=_data.get('bed_empty', '0'),
                  price=_data.get('cost', '0'),
                  available=_data.get('availiable'),
                  GLon=_data.get('GLon'),
                  GLat=_data.get('GLat'),
                  WLon=_data.get('WLon'),
                  WLat=_data.get('WLat'),
                  region=_data.get('region'),
                  facility=_data.get('id', '无'),

                  cost=_data.get('avacost'),
                  bed_used=_data.get('beduse'),
                  level=_data.get('level'),
                  service=_data.get('service'),
                  greenland=_data.get('greenland'),
                  hospital=_data.get('hospital'),
                  drugstore=_data.get('drugstore'),
                  park_square=_data.get('park&square'),
                  bus_stop=_data.get('busstop'),
                  metro_station=_data.get('metrostation'),
                  shop=_data.get('shop'))
    elif _agency == '综合为老服务中心':
        return CS(id=_data.get('id'),
                  name=_data.get('name'),
                  picture=_data.get('picture'),
                  set_time=_data.get('settime', '0001-01-01'),
                  area=_data.get('area', '0'),
                  telephone=_data.get('telephone', ''),
                  address=_data.get('address'),
                  GLon=_data.get('GLon'),
                  GLat=_data.get('GLat'),
                  WLon=_data.get('WLon'),
                  WLat=_data.get('WLat'),
                  region=_data.get('region'),
                  service_content=_data.get('service_content'),

                  cost=_data.get('avacost'),
                  bed_used=_data.get('beduse'),
                  level=_data.get('level'),
                  service=_data.get('service'),
                  greenland=_data.get('greenland'),
                  hospital=_data.get('hospital'),
                  drugstore=_data.get('drugstore'),
                  park_square=_data.get('park&square'),
                  bus_stop=_data.get('busstop'),
                  metro_station=_data.get('metrostation'),
                  shop=_data.get('shop'))
    elif _agency == '社区养老':
        return EC(id=_data.get('id'),
                  name=_data.get('name'),
                  picture=_data.get('picture'),
                  set_time=_data.get('settime', '0001-01-01'),
                  telephone=_data.get('telephone', ''),
                  address=_data.get('address'),
                  available=_data.get('availiable'),
                  GLon=_data.get('GLon'),
                  GLat=_data.get('GLat'),
                  WLon=_data.get('WLon'),
                  WLat=_data.get('WLat'),
                  region=_data.get('region'),
                  service_content=_data.get('service_content'),

                  cost=_data.get('avacost'),
                  bed_used=_data.get('beduse'),
                  level=_data.get('level'),
                  service=_data.get('service'),
                  greenland=_data.get('greenland'),
                  hospital=_data.get('hospital'),
                  drugstore=_data.get('drugstore'),
                  park_square=_data.get('park&square'),
                  bus_stop=_data.get('busstop'),
                  metro_station=_data.get('metrostation'),
                  shop=_data.get('shop'))
    elif _agency == '助餐服务点':
        return FS(id=_data.get('id'),
                  name=_data.get('name'),
                  picture=_data.get('picture'),
                  set_time=_data.get('settime', '0001-01-01'),
                  telephone=_data.get('telephone', ''),
                  address=_data.get('address'),
                  GLon=_data.get('GLon'),
                  GLat=_data.get('GLat'),
                  WLon=_data.get('WLon'),
                  WLat=_data.get('WLat'),
                  region=_data.get('region'),
                  service_time=_data.get('service_time'),
                  service_type=_data.get('service_type'),

                  cost=_data.get('avacost'),
                  bed_used=_data.get('beduse'),
                  level=_data.get('level'),
                  service=_data.get('service'),
                  greenland=_data.get('greenland'),
                  hospital=_data.get('hospital'),
                  drugstore=_data.get('drugstore'),
                  park_square=_data.get('park&square'),
                  bus_stop=_data.get('busstop'),
                  metro_station=_data.get('metrostation'),
                  shop=_data.get('shop'))
    elif _agency == '护理站\\院':
        return NS(id=_data.get('id'),
                  name=_data.get('name'),
                  picture=_data.get('picture'),
                  address=_data.get('address'),
                  available=_data.get('availiable'),
                  GLon=_data.get('GLon'),
                  GLat=_data.get('GLat'),
                  WLon=_data.get('WLon'),
                  WLat=_data.get('WLat'),
                  region=_data.get('region'),
                  certificate=_data.get('certificate'),

                  cost=_data.get('avacost'),
                  bed_used=_data.get('beduse'),
                  level=_data.get('level'),
                  service=_data.get('service'),
                  greenland=_data.get('greenland'),
                  hospital=_data.get('hospital'),
                  drugstore=_data.get('drugstore'),
                  park_square=_data.get('park&square'),
                  bus_stop=_data.get('busstop'),
                  metro_station=_data.get('metrostation'),
                  shop=_data.get('shop'))
    elif _agency == '老年日间照护机构':
        return ED(id=_data.get('id'),
                  name=_data.get('name'),
                  picture=_data.get('picture'),
                  set_time=_data.get('settime', '0001-01-01'),
                  telephone=_data.get('telephone', ''),
                  address=_data.get('address'),
                  bed_all=_data.get('bed_all', '0'),
                  GLon=_data.get('GLon'),
                  GLat=_data.get('GLat'),
                  WLon=_data.get('WLon'),
                  WLat=_data.get('WLat'),
                  region=_data.get('region'),

                  cost=_data.get('avacost'),
                  bed_used=_data.get('beduse'),
                  level=_data.get('level'),
                  service=_data.get('service'),
                  greenland=_data.get('greenland'),
                  hospital=_data.get('hospital'),
                  drugstore=_data.get('drugstore'),
                  park_square=_data.get('park&square'),
                  bus_stop=_data.get('busstop'),
                  metro_station=_data.get('metrostation'),
                  shop=_data.get('shop'))
    elif _agency == '长者照护之家':
        return EN(id=_data.get('id'),
                  name=_data.get('name'),
                  picture=_data.get('picture'),
                  set_time=_data.get('settime', '0001-01-01'),
                  telephone=_data.get('telephone', ''),
                  address=_data.get('address'),
                  bed_all=_data.get('bed_all', '0'),
                  price=_data.get('cost', '0'),
                  available=_data.get('availiable'),
                  GLon=_data.get('GLon'),
                  GLat=_data.get('GLat'),
                  WLon=_data.get('WLon'),
                  WLat=_data.get('WLat'),
                  region=_data.get('region'),
                  facility=_data.get('facility', '无'),

                  cost=_data.get('avacost'),
                  bed_used=_data.get('beduse'),
                  level=_data.get('level'),
                  service=_data.get('service'),
                  greenland=_data.get('greenland'),
                  hospital=_data.get('hospital'),
                  drugstore=_data.get('drugstore'),
                  park_square=_data.get('park&square'),
                  bus_stop=_data.get('busstop'),
                  metro_station=_data.get('metrostation'),
                  shop=_data.get('shop'))


agency = {'养老机构': NH, '护理站/院': NS,
          '老年日间照护机构': ED, '长者照护之家': EN,
          '助餐服务点': FS, '社区养老': EC,
          '综合为老服务中心': CS}


def get(dbname, _id=-1):
    db = agency[dbname]
    # 创建Query查询，filter是where条件，最后调用one()返回唯一行，如果调用all()则返回所有行:
    if _id == -1:
        _data = session.query(db).all()
    else:
        _data = session.query(db).filter_by(id=_id).all()
    return _data


def insert(_type, _data):
    return


if __name__ == '__main__':
    with open("../data/PensionSector.json") as f:
        data = json.load(f)
    i = 0
    metadata.create_all(con_engine)
    for agency in data:
        info = data[agency]
        for d in info:
            session.add(create(agency, d))
            session.commit()
            i += 1
            print(agency + str(i))
    # agency = '综合为老服务中心'
    # info = data[agency]
    # for d in info:
    #     session.add(create(agency, d))
    #     session.commit()
    #     i += 1
    #     print(agency + str(i))
