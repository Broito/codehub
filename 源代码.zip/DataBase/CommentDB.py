import json
from sqlalchemy import Column, Float, Integer, Text, create_engine
from sqlalchemy.dialects.mysql import TINYTEXT
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker


con_engine = create_engine('mysql+pymysql://root:AEight19731224@localhost:3306/PensionWeb')
Base = declarative_base()
metadata = Base.metadata
DBSession = sessionmaker(bind=con_engine)
session = DBSession()


# 养老院评论 Comments
class Comments(Base):
    __tablename__ = 'Comments'

    uid = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(TINYTEXT)
    content = Column(Text)
    tag = Column(Text)

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


def create(_name, _content, _tag):
    return Comments(name=_name,
                    content=_content,
                    tag=_tag)


def get(_name=None):
    # 创建Query查询，filter是where条件，最后调用one()返回唯一行，
    if _name is None:
        _data = session.query(Comments).all()
    else:
        _data = session.query(Comments).filter_by(name=_name).all()
    return _data


def insert(_name, _content, _req):
    metadata.create_all(con_engine)
    session.add(create(_name, _content, ReqToText(_req)))
    session.commit()
    return {'code': '201000', 'message': '入库成功'}


def ReqToText(_req):
    _text = []
    for i in _req:
        _text.append('&LB'.join([str(j) for j in list(i.values())]))
    return '&BB'.join(_text)


if __name__ == '__main__':
    with open("../data/comment.json") as f:
        data = json.load(f)
    i = 0
    metadata.create_all(con_engine)
    for agency in data:
        info = data[agency]
        for d in info:
            session.add(create(agency, d))
            session.commit()
            i += 1
            print(agency + str(i))
