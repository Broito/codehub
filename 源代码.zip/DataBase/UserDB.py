from sqlalchemy import Column, Float, Integer, Text, create_engine, ForeignKey
from sqlalchemy.dialects.mysql import TINYTEXT
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

con_engine = create_engine('mysql+pymysql://root:AEight19731224@localhost:3306/PensionWeb')
Base = declarative_base()
metadata = Base.metadata
DBSession = sessionmaker(bind=con_engine)
session = DBSession()


# 用户信息 users
class Users(Base):
    __tablename__ = 'users'

    uid = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(TINYTEXT)
    password = Column(TINYTEXT)
    # authority = Column(TINYTEXT, server_default='common')

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


# # IP访问记录 IP_Record
# class IP_Record(Base):
#     __tablename__ = 'iprecord'
#
#     record_id = Column(Integer, primary_key=True, autoincrement=True)
#     uid = Column(Integer, ForeignKey('users.uid'))
#     username = Column(TINYTEXT)
#     password = Column(TINYTEXT)
#     users = relationship("users", backref="iprecord")
#
#     def to_dict(self):
#         return {c.name: getattr(self, c.name) for c in self.__table__.columns}


def create(_name, _pwd):
    return Users(username=_name,
                 password=_pwd)


def get():
    # 创建Query查询，filter是where条件，最后调用one()返回唯一行，如果调用all()则返回所有行:
    _data = session.query(Users).all()
    return _data


def verify(_uid, _pwd):
    _data = session.query(Users).filter_by(uid=_uid).all()
    if len(_data) == 0:
        return {'code': '101000', 'message': '用户名不存在'}
    elif _data[0].password == _pwd:
        return {'code': '100000', 'message': '登陆成功'}
    else:
        return {'code': '101001', 'message': '密码错误'}


def insert(_name, _pwd):
    repetition = session.query(Users).filter_by(username=_name).all()
    if repetition:
        return {'code': '201000', 'message': '用户名已存在'}
    else:
        metadata.create_all(con_engine)
        session.add(create(_name, _pwd))
        session.commit()
        return {'code': '200000', 'message': '注册成功'}


if __name__ == '__main__':
    metadata.create_all(con_engine)
    insert('AEight1973', 'wzq19731224')
