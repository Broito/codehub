import flask
import json
from flask import request
from flask_cors import CORS
from DataBase import UserDB

'''
flask： web框架，通过flask提供的装饰器@server.route()将普通函数转换为服务
登录接口，需要传url、username、passwd
'''
# 创建一个服务，把当前这个python文件当做一个服务
server = flask.Flask(__name__)
CORS(server, resources=r'/*')


# @server.route()可以将普通函数转变为服务 登录接口的路径、请求方式
@server.route('/login', methods=['GET', 'POST'])
def login():
    # 获取通过url请求传参的数据
    username = request.values.get('name')
    # 获取url请求传的密码，明文
    pwd = request.values.get('pwd')
    # 判断用户名、密码都不为空，如果不传用户名、密码则username和pwd为None
    if username and pwd:
        resume = UserDB.verify(username, pwd)
        return json.dumps(resume)
    else:
        resume = {'code': '101002', 'message': '账号密码不能为空！'}
        return json.dumps(resume)


@server.route('/register', methods=['GET', 'POST'])
def register():
    # 获取通过url请求传参的数据
    name = request.values.get('name')
    # 获取url请求传的密码，明文
    pwd = request.values.get('pwd')
    # 判断用户名、密码都不为空，如果不传用户名、密码则username和pwd为None
    if name and pwd:
        resume = UserDB.insert(name, pwd)
        return json.dumps(resume)
    else:
        resume = {'code': '201003', 'message': '账号密码不能为空！'}
        return json.dumps(resume)


if __name__ == '__main__':
    server.run(debug=True, port=8800, host='0.0.0.0')  # 指定端口、host,0.0.0.0代表不管几个网卡，任何ip都可以访问
