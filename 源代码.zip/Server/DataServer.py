import flask
import json
from flask import request
from flask_cors import CORS
from DataBase import PensionDB
from ToolBox.DBTool import simple, detailed, to_json
from ToolBox.GeoTool import distance

'''
flask： web框架，通过flask提供的装饰器@server.route()将普通函数转换为服务
登录接口，需要传url、username、passwd
'''
# 创建一个服务，把当前这个python文件当做一个服务
server = flask.Flask(__name__)
CORS(server, resources=r'/*')


class SuggestModel:
    def __init__(self, _position, _type, _region, _change):
        self.weight = {"distance": -0.2857, "greenland": 0.1429, "hospital": 0.0327,
                       "drugstore": 0.0244, "park_square": 0.0302, "shop": 0.0269,
                       "metro_station": 0.0144, "bus_stop": 0.0142, "cost": -0.0857,
                       "service": 0.1143, "level": 0.1143, "bed_used": -0.1143}
        self._change(_change)
        self.position = _position
        self.type = _type
        self.region = _region
        self.suggest = [{'id': 0, 'score': -10000},
                        {'id': 1, 'score': -10000},
                        {'id': 2, 'score': -10000},
                        {'id': 3, 'score': -10000},
                        {'id': 4, 'score': -10000}]
        self.output = []

    # 根据用户选择调整参数
    def _change(self, value):
        if value == 1:
            self.weight["distance"] *= 2
        elif value == 2:
            self.weight["greenland"] *= 2
        elif value == 3:
            self.weight["hospital"] *= 2
            self.weight["drugstore"] *= 2
        elif value == 4:
            self.weight["park_square"] *= 2
            self.weight["shop"] *= 2
        elif value == 5:
            self.weight["metro_station"] *= 2
            self.weight["bus_stop"] *= 2
        elif value == 6:
            self.weight["cost"] *= 2
        elif value == 7:
            self.weight["service"] *= 2
            self.weight["level"] *= 2
            self.weight["bed_used"] *= 2

    # 更新当前推荐列表
    def _suggest(self, name, value):
        for i in range(5):
            if value > self.suggest[i]['score']:
                self.suggest[i]['id'] = name
                self.suggest[i]['score'] = value
                break

    def _refresh_info(self):
        for a in self.suggest:
            info = PensionDB.get(self.type, a['id'])[0]
            output = dict()
            output['id'] = info.id
            output['name'] = info.name
            output['address'] = info.address
            output['telephone'] = info.telephone
            output['GLon'] = info.GLon
            output['GLat'] = info.GLat
            self.output.append(output)

    def run(self):
        lon0 = self.position.get('lng')
        lat0 = self.position.get('lat')
        agency = PensionDB.get(self.type)
        for ps in agency:
            if self.region == '' or ps.region == self.region and ps.bed_all != 0 and ps.available != '否':
                value = 0
                dis = distance(lon0, lat0, ps.GLon, ps.GLat)
                value += dis * self.weight['distance']
                value += ps.greenland * self.weight['greenland']
                value += ps.hospital * self.weight['hospital']
                value += ps.drugstore * self.weight['drugstore']
                value += ps.park_square * self.weight['park_square']
                value += ps.shop * self.weight['shop']
                value += ps.metro_station * self.weight['metro_station']
                value += ps.bus_stop * self.weight['bus_stop']
                value += ps.cost * self.weight['cost']
                value += ps.service * self.weight['service']
                value += ps.level * self.weight['level']
                value += ps.bed_used * self.weight['bed_used']
                self._suggest(ps.id, value)
        self._refresh_info()


# @server.route()可以将普通函数转变为服务 登录接口的路径、请求方式
@server.route('/suggest', methods=['GET', 'POST'])
# 推荐算法主函数
def suggest():
    # 获取通过url请求传参的数据
    current_poi = {'lng': request.values.get('Lng'), 'lat': request.values.get('Lat')}
    agency_type = request.values.get('AgencyType')
    region = request.values.get('Region')
    change = request.values.get('Changelist')

    # 建立推荐模型并计算
    model = SuggestModel(current_poi, agency_type, region, change)
    model.run()

    # 返回计算完成数据
    resume = {'code': '500000', 'message': model.output}
    return json.dumps(resume)


@server.route('/lead5', methods=['GET', 'POST'])
def lead5():
    # 获取通过url请求传参的数据
    agency_type = request.values.get('AgencyType')

    # 读取数据
    data = PensionDB.get(agency_type)[: 5]
    resume = {'code': '400000', 'message': simple(agency_type, data)}
    return json.dumps(resume)


@server.route('/total', methods=['GET', 'POST'])
def total():
    agency_list = ['养老机构', '护理站/院', '老年日间照护机构', '长者照护之家', '助餐服务点', '社区养老', '综合为老服务中心']
    total_list = {}
    for i in agency_list:
        data = PensionDB.get(i)
        total_list[i] = simple(i, data)
    resume = {'code': '400000', 'message': total_list}
    return json.dumps(resume)


@server.route('/detail', methods=['GET', 'POST'])
def detail():
    # 获取通过url请求传参的数据
    agency_type = request.values.get('AgencyType')
    uid = request.values.get('ID')

    # 读取数据
    data = PensionDB.get(agency_type, uid)
    resume = {'code': '400000', 'message': detailed(data)}
    return json.dumps(resume)


if __name__ == '__main__':
    server.run(debug=True, port=8801, host='0.0.0.0')  # 指定端口、host,0.0.0.0代表不管几个网卡，任何ip都可以访问
