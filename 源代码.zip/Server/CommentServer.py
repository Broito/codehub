import flask
import json
from flask import request
from flask_cors import CORS
from DataBase import CommentDB
import CommentPoint_BaiduAPI as CP
from ToolBox.DBTool import to_json

'''
flask： web框架，通过flask提供的装饰器@server.route()将普通函数转换为服务
登录接口，需要传url、username、passwd
'''
# 创建一个服务，把当前这个python文件当做一个服务
server = flask.Flask(__name__)
CORS(server, resources=r'/*')


def TextToReq(_text):
    if _text == '':
        return []
    _req = []
    _list = _text.split('&BB')
    for i in _list:
        _info = i.split('&LB')
        _req.append({'sentiment': int(_info[0]),
                     'abstract': _info[1],
                     'prop': _info[2],
                     'begin_pos': int(_info[3]),
                     'end_pos': int(_info[4]),
                     'adj': _info[5]})
    return _req


@server.route('/save_comment', methods=['GET', 'POST'])
def save_comment():
    # 获取通过url请求传参的数据
    name = request.values.get('Name')
    content = request.values.get('Content')

    # 通过百度API提取评论关键词
    req = CP.get_comment_tag(content)

    # 导入数据库
    CommentDB.insert(name, content, req)
    return json.dumps({{'code': 10001, 'message': '评论导入成功'}})


@server.route('/get_comment', methods=['GET', 'POST'])
def get_comment():
    # 获取通过url请求传参的数据
    name = request.values.get('Name')

    comments = to_json(CommentDB.get(name))
    for i in comments:
        i['tag'] = TextToReq(i['tag'])
    return json.dumps({'code': 10002, 'message': comments})


if __name__ == '__main__':
    server.run(debug=True, port=8802, host='0.0.0.0')  # 指定端口、host,0.0.0.0代表不管几个网卡，任何ip都可以访问
